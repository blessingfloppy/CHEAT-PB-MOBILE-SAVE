'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const controls = new Map();
const makeControl = () => ({
  checked: false,
  value: '',
  listeners: new Map(),
  addEventListener(type, callback) { this.listeners.set(type, callback); },
  fire(type) { this.listeners.get(type)?.(); }
});

const panel = {
  style: {},
  innerHTML: '',
  querySelector(selector) {
    if (!controls.has(selector)) controls.set(selector, makeControl());
    return controls.get(selector);
  }
};

const canvas = {
  style: {},
  width: 0,
  height: 0,
  getContext() { return { clearRect() {} }; }
};

const original = {
  clone() {
    return {
      map: {}, alphaMap: {},
      color: { set(value) { this.value = value; } },
      emissive: { set(value) { this.value = value; } },
      dispose() { this.disposed = true; }
    };
  }
};

const mesh = { isMesh: true, material: original, renderOrder: 0 };
const self = { team: 1, hp: 100 };
const enemy = {
  team: 2,
  hp: 100,
  obj: {
    matrixWorld: { elements: Array.from({ length: 16 }, (_, index) => index === 13 ? -1.55 : index === 14 ? 10 : 0) },
    traverse(callback) { callback(mesh); }
  }
};

const environment = {
  window: { G: {
    P: { s: self },
    bots: [self, enemy],
    camera: { position: { clone() { return {
      set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; },
      project() { this.x /= 10; this.y /= 10; this.z = 0; return this; }
    }; } } }
  } },
  document: {
    body: { appendChild() {} },
    createElement(tag) { return tag === 'canvas' ? canvas : panel; }
  },
  localStorage: { getItem() { return null; }, setItem() {} },
  setInterval() { return 1; },
  clearInterval() {},
  setTimeout() {},
  innerWidth: 1920,
  innerHeight: 1080
};

const source = fs.readFileSync(path.join(__dirname, 'skeleton.js'), 'utf8');
vm.runInNewContext(source, environment);

const chams = controls.get('#phb-chams');
assert.equal(chams.checked, false);
assert.equal(mesh.material, original);

chams.checked = true;
chams.fire('change');
assert.notEqual(mesh.material, original);
assert.equal(mesh.material.depthTest, false);
assert.equal(mesh.renderOrder, 9999);

const painted = mesh.material;
controls.get('#phb-chams-color').value = 'cyan';
controls.get('#phb-chams-color').fire('change');
assert.equal(painted.color.value, '#31dbef');

chams.checked = false;
chams.fire('change');
assert.equal(mesh.material, original);
assert.equal(mesh.renderOrder, 0);
assert.equal(painted.disposed, true);

assert.equal(controls.has('#phb-aim'), false);
assert.equal('__pemburuhsAimBullet' in environment.window, false);
console.log('Chams ON/OFF dan Aim Bullet tidak ada: OK');
