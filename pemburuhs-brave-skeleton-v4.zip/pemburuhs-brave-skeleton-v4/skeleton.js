(() => {
  'use strict';
  if (window.__pemburuhsMobileLite) return;
  window.__pemburuhsMobileLite = true;

  const storageKey = 'pemburuhs_brave_skeleton_v1';
  const pairs = [
    ['Head', 'Neck'], ['Neck', 'Spine3'], ['Spine3', 'Spine2'],
    ['Spine2', 'Spine1'], ['Spine1', 'Pelvis'],
    ['Spine3', 'L_Clavicle'], ['L_Clavicle', 'L_UpperArm'],
    ['L_UpperArm', 'L_Forearm'], ['L_Forearm', 'L_Hand'],
    ['Spine3', 'R_Clavicle'], ['R_Clavicle', 'R_UpperArm'],
    ['R_UpperArm', 'R_Forearm'], ['R_Forearm', 'R_Hand'],
    ['Pelvis', 'L_Thigh'], ['L_Thigh', 'L_Calf'], ['L_Calf', 'L_Foot'],
    ['Pelvis', 'R_Thigh'], ['R_Thigh', 'R_Calf'], ['R_Calf', 'R_Foot']
  ];

  const canvas = document.createElement('canvas');
  canvas.setAttribute('data-pb', '1');
  canvas.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:2147483000;display:none';
  const context = canvas.getContext('2d');
  const panel = document.createElement('div');
  panel.setAttribute('data-pb', '1');
  panel.style.cssText = 'position:fixed;top:12px;right:12px;z-index:2147483001;background:#171717;color:#eee;border:1px solid #555;border-radius:8px;padding:10px 12px;font:12px system-ui,sans-serif;box-shadow:0 8px 24px #0008;min-width:175px';
  panel.innerHTML = '<div style="font-weight:700;margin-bottom:9px">CHEAT PB MOBILE SAVE</div><label style="display:flex;align-items:center;justify-content:space-between;gap:12px">Skeleton ESP <input type="checkbox" id="phb-on"></label><label style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:9px">Chams <input type="checkbox" id="phb-chams"></label><label style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:9px">Warna Chams <select id="phb-chams-color" style="background:#292929;color:#eee;border:1px solid #666;border-radius:4px;padding:2px"><option value="red">Merah</option><option value="cyan">Cyan</option><option value="yellow">Kuning</option><option value="green">Hijau</option><option value="purple">Ungu</option></select></label><label style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:9px">Jarak <input type="range" id="phb-range" min="20" max="120" step="5" value="60" style="width:95px"></label><div id="phb-status" style="color:#aaa;font-size:10px;margin-top:8px">ESP OFF</div><div id="phb-chams-status" style="color:#aaa;font-size:10px;margin-top:3px">Chams OFF</div>';

  const onInput = panel.querySelector('#phb-on');
  const rangeInput = panel.querySelector('#phb-range');
  const chamsInput = panel.querySelector('#phb-chams');
  const chamsColorInput = panel.querySelector('#phb-chams-color');
  const status = panel.querySelector('#phb-status');
  const chamsStatus = panel.querySelector('#phb-chams-status');
  const state = { enabled: false, range: 60, timer: null, vector: null };
  const chamsPalette = Object.freeze({ red: '#ff4141', cyan: '#31dbef', yellow: '#ffd84a', green: '#65e47a', purple: '#c77cff' });
  const chamsState = { color: 'red', timer: null, records: new Map() };

  try {
    const saved = JSON.parse(localStorage.getItem(storageKey) || '{}');
    state.enabled = false;
    if (Number.isFinite(saved.range) && saved.range >= 20 && saved.range <= 120) state.range = saved.range;
    if (Object.prototype.hasOwnProperty.call(chamsPalette, saved.chamsColor)) chamsState.color = saved.chamsColor;
  } catch (_) {}
  onInput.checked = state.enabled;
  chamsInput.checked = false;
  chamsColorInput.value = chamsState.color;
  rangeInput.value = String(state.range);

  const save = () => {
    try { localStorage.setItem(storageKey, JSON.stringify({ range: state.range, chamsColor: chamsState.color })); } catch (_) {}
  };

  const restoreChamsMesh = (mesh, record) => {
    if (mesh.material === record.painted) mesh.material = record.original;
    mesh.renderOrder = record.renderOrder;
    mesh.onBeforeRender = record.onBeforeRender;
    for (const material of record.clones) material.dispose();
    chamsState.records.delete(mesh);
  };

  const restoreChams = () => {
    for (const [mesh, record] of chamsState.records) restoreChamsMesh(mesh, record);
  };

  const paintChamsMaterial = material => {
    const clone = material.clone();
    clone.map = null;
    clone.alphaMap = null;
    clone.color?.set(chamsPalette[chamsState.color]);
    clone.emissive?.set(chamsPalette[chamsState.color]);
    if ('emissiveIntensity' in clone) clone.emissiveIntensity = 0.35;
    clone.transparent = false;
    clone.depthTest = true;
    clone.depthFunc = 3;
    clone.depthWrite = false;
    clone.needsUpdate = true;
    return clone;
  };

  let lastDepthClear = 0;
  const clearChamsDepth = renderer => {
    const now = performance.now();
    if (now - lastDepthClear < 4) return;
    lastDepthClear = now;
    renderer.clearDepth();
  };

  const applyChamsMesh = mesh => {
    const existing = chamsState.records.get(mesh);
    if (existing && mesh.material === existing.painted) return;
    if (existing) restoreChamsMesh(mesh, existing);
    const original = mesh.material;
    if (!original) return;
    const materials = Array.isArray(original) ? original : [original];
    if (materials.some(material => typeof material?.clone !== 'function')) return;
    const clones = materials.map(paintChamsMaterial);
    const painted = Array.isArray(original) ? clones : clones[0];
    chamsState.records.set(mesh, { original, painted, clones, renderOrder: mesh.renderOrder, onBeforeRender: mesh.onBeforeRender });
    mesh.material = painted;
    mesh.renderOrder = 500;
    mesh.onBeforeRender = clearChamsDepth;
  };

  const scanChams = () => {
    const game = window.G;
    if (!game?.P?.s || !Array.isArray(game.bots)) {
      restoreChams();
      chamsStatus.textContent = 'Chams menunggu match';
      return;
    }
    const self = game.P.s;
    const seen = new Set();
    let enemies = 0;
    for (const player of game.bots) {
      if (!player || player === self || player.team === self.team || player.dead || !(player.hp > 0)) continue;
      if (typeof player.obj?.traverse !== 'function') continue;
      enemies++;
      player.obj.traverse(node => {
        if (!node.isMesh && !node.isSkinnedMesh) return;
        seen.add(node);
        applyChamsMesh(node);
      });
    }
    for (const [mesh, record] of chamsState.records) {
      if (!seen.has(mesh)) restoreChamsMesh(mesh, record);
    }
    chamsStatus.textContent = 'Chams ON · ' + enemies + ' musuh';
  };

  const stopChams = () => {
    if (chamsState.timer !== null) clearInterval(chamsState.timer);
    chamsState.timer = null;
    restoreChams();
    chamsStatus.textContent = 'Chams OFF';
  };

  const startChams = () => {
    try { scanChams(); } catch (_) { chamsStatus.textContent = 'Chams: model berubah'; }
    if (chamsState.timer === null) chamsState.timer = setInterval(() => {
      try { scanChams(); } catch (_) { chamsStatus.textContent = 'Chams: model berubah'; }
    }, 750);
  };

  const stop = () => {
    if (state.timer !== null) clearInterval(state.timer);
    state.timer = null;
    canvas.style.display = 'none';
    context.clearRect(0, 0, canvas.width, canvas.height);
    status.textContent = 'OFF';
  };

  const bone = (bones, name) => bones[name] || bones[name.toLowerCase()] || bones['Bone_' + name] || null;

  const draw = () => {
    const game = window.G;
    if (!game || !game.camera || !game.P || !game.P.s || !Array.isArray(game.bots)) {
      status.textContent = 'Menunggu match';
      context.clearRect(0, 0, canvas.width, canvas.height);
      return;
    }
    const self = game.P.s;
    if (self.dead) {
      context.clearRect(0, 0, canvas.width, canvas.height);
      return;
    }
    const camera = game.camera;
    if (!camera.position || !camera.matrixWorld) return;
    const scale = Math.min(window.devicePixelRatio || 1, 1.5);
    const width = Math.round(innerWidth * scale);
    const height = Math.round(innerHeight * scale);
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }
    context.setTransform(scale, 0, 0, scale, 0, 0);
    context.clearRect(0, 0, innerWidth, innerHeight);
    context.strokeStyle = 'rgba(220,220,220,.85)';
    context.lineWidth = 1.3;
    state.vector ||= camera.position.clone();
    const cameraMatrix = camera.matrixWorld.elements;
    const origin = { x: cameraMatrix[12], y: cameraMatrix[13], z: cameraMatrix[14] };
    let shown = 0;

    for (const player of game.bots) {
      if (!player || player === self || player.team === self.team || player.dead || !(player.hp > 0)) continue;
      if (!player.obj?.matrixWorld?.elements || !player.c?.byName) continue;
      const matrix = player.obj.matrixWorld.elements;
      const distance = Math.hypot(matrix[12] - origin.x, matrix[13] - origin.y, matrix[14] - origin.z);
      if (distance > state.range) continue;

      const projected = new Map();
      const point = name => {
        if (projected.has(name)) return projected.get(name);
        const part = bone(player.c.byName, name);
        if (!part?.matrixWorld?.elements) { projected.set(name, null); return null; }
        const position = part.matrixWorld.elements;
        const value = state.vector.set(position[12], position[13], position[14]).project(camera);
        const result = value.z > -1 && value.z < 1
          ? { x: (value.x * .5 + .5) * innerWidth, y: (-value.y * .5 + .5) * innerHeight }
          : null;
        projected.set(name, result);
        return result;
      };

      let drew = false;
      for (const [first, second] of pairs) {
        const a = point(first);
        const b = point(second);
        if (!a || !b) continue;
        context.beginPath();
        context.moveTo(a.x, a.y);
        context.lineTo(b.x, b.y);
        context.stroke();
        drew = true;
      }
      if (drew) shown++;
    }
    status.textContent = 'ON · ' + shown + ' target';
  };

  const start = () => {
    canvas.style.display = 'block';
    status.textContent = 'Menunggu match';
    if (state.timer === null) state.timer = setInterval(() => {
      try { draw(); } catch (_) { status.textContent = 'Objek game berubah'; }
    }, 50);
  };

  onInput.addEventListener('change', () => {
    state.enabled = onInput.checked;
    save();
    state.enabled ? start() : stop();
  });
  chamsInput.addEventListener('change', () => {
    chamsInput.checked ? startChams() : stopChams();
  });
  chamsColorInput.addEventListener('change', () => {
    chamsState.color = chamsColorInput.value;
    save();
    for (const record of chamsState.records.values()) {
      for (const material of record.clones) {
        material.color?.set(chamsPalette[chamsState.color]);
        material.emissive?.set(chamsPalette[chamsState.color]);
      }
    }
  });
  rangeInput.addEventListener('input', () => {
    state.range = Number(rangeInput.value);
    save();
  });

  const mount = () => {
    const host = document.body || document.documentElement;
    if (!host) { setTimeout(mount, 50); return; }
    host.appendChild(canvas);
    host.appendChild(panel);
    if (state.enabled) start();
  };
  mount();
})();
